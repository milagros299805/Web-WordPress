window.alert("Bienvenido a mi portafolio");

var burger = document.querySelector(".burger");
var menu = document.querySelector(".header__nav");

burger.addEventListener("click", function(e){
	e.preventDefault();
	menu.classList.toogle("header__nav--visible");
});