
	<footer class="footer">
		
		<p>¡Gracias por la visita! Encuéntranos también en</p>

		<ul class="icons__footer">
			
			<li><span class="icon-behance2"></li>
			<li><span class="icon-whatsapp"></li>
			<li><span class="icon-instagram"></li>
			<li><span class="icon-facebook2"></li>
		</ul>



	</footer>
	<?php wp_footer(); ?>

</body>

</html>